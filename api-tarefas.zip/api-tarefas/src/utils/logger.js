function log(message) {
  console.log(`[LOG]: ${message}`);
}
module.exports = log;